xdg-mime default evince.desktop application/pdf
