# Defaults for amxa-desktop-extra initscript
# sourced by /etc/init.d/amxa-desktop-extra
# installed at /etc/default/amxa-desktop-extra by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
