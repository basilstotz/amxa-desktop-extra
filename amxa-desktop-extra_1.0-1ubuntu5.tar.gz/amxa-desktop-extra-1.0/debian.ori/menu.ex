?package(amxa-desktop-extra):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-desktop-extra" command="/usr/bin/amxa-desktop-extra"
